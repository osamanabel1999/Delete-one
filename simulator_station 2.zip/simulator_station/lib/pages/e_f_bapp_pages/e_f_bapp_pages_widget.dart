import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/actions/actions.dart' as action_blocks;
import '/custom_code/actions/index.dart' as actions;
import '/custom_code/widgets/index.dart' as custom_widgets;
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'e_f_bapp_pages_model.dart';
export 'e_f_bapp_pages_model.dart';

class EFBappPagesWidget extends StatefulWidget {
  const EFBappPagesWidget({super.key});

  static String routeName = 'EFBappPages';
  static String routePath = '/eFBappPages';

  @override
  State<EFBappPagesWidget> createState() => _EFBappPagesWidgetState();
}

class _EFBappPagesWidgetState extends State<EFBappPagesWidget> {
  late EFBappPagesModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => EFBappPagesModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            if (FFAppState().EFBpageNumber == 10.0)
              Expanded(
                child: Container(
                  width: double.infinity,
                  height: double.infinity,
                  child: custom_widgets.EfbBrowserScreen(
                    width: double.infinity,
                    height: double.infinity,
                  ),
                ),
              ),
            if (FFAppState().EFBpageNumber == 8.0)
              Expanded(
                child: Container(
                  width: double.infinity,
                  height: double.infinity,
                  child: custom_widgets.EfbLibraryScreen(
                    width: double.infinity,
                    height: double.infinity,
                  ),
                ),
              ),
            if (FFAppState().EFBpageNumber == 6.0)
              Expanded(
                child: Container(
                  width: double.infinity,
                  height: double.infinity,
                  child: custom_widgets.EfbCalculatorsScreen(
                    width: double.infinity,
                    height: double.infinity,
                  ),
                ),
              ),
            if (FFAppState().EFBpageNumber == 9.0)
              Expanded(
                child: Container(
                  width: double.infinity,
                  height: double.infinity,
                  child: custom_widgets.CabinPaSystemScreen(
                    width: double.infinity,
                    height: double.infinity,
                  ),
                ),
              ),
            if (FFAppState().EFBpageNumber == 2.0)
              Expanded(
                child: Container(
                  width: double.infinity,
                  height: double.infinity,
                  child: custom_widgets.EfbBriefingScreen(
                    width: double.infinity,
                    height: double.infinity,
                    pilotId: FFAppState().SimbreifID.toString(),
                  ),
                ),
              ),
            if (FFAppState().EFBpageNumber == 1.0)
              Expanded(
                child: Container(
                  width: double.infinity,
                  height: double.infinity,
                  child: custom_widgets.AiDispatcherScreen(
                    width: double.infinity,
                    height: double.infinity,
                  ),
                ),
              ),
            if (FFAppState().EFBpageNumber == 7.0)
              Expanded(
                child: Container(
                  width: double.infinity,
                  height: double.infinity,
                  child: custom_widgets.ChecklistEFBmsfs(
                    width: double.infinity,
                    height: double.infinity,
                    onA320CockpitPrep: () async {
                      await actions.runCockpitPreparation();
                    },
                    onA320BeforeStart: () async {
                      await actions.runBeforeStartChecklist();
                    },
                    onA320AfterStart: () async {
                      await actions.runAfterStartChecklist();
                    },
                    onA320Taxi: () async {
                      await actions.runTaxiChecklist();
                    },
                    onA320Lineup: () async {
                      await actions.runLineUpChecklist();
                    },
                    onA320DepartureChange: () async {
                      await actions.runDepartureChecklist();
                    },
                    onA320Approach: () async {
                      await actions.runApproachChecklist();
                    },
                    onA320Landing: () async {
                      await actions.runLandingChecklist();
                    },
                    onA320AfterLanding: () async {
                      await actions.runAfterLandingChecklist();
                    },
                    onA320Parking: () async {
                      await actions.runParkingChecklist();
                    },
                    onA320SecuringAircraft: () async {
                      await actions.runSecuringChecklist();
                    },
                    onB737Preflight: () async {
                      await action_blocks.test(context);
                    },
                    onB737BeforeStart: () async {
                      await actions.runB737BeforeStartChecklist();
                    },
                    onB737BeforeTaxi: () async {
                      await actions.runB737BeforeTaxiChecklist();
                    },
                    onB737BeforeTakeoff: () async {
                      await actions.runB737BeforeTakeoffChecklist();
                    },
                    onB737AfterTakeoff: () async {
                      await actions.runB737AfterTakeoffChecklist();
                    },
                    onB737Descent: () async {
                      await actions.runB737DescentChecklist();
                    },
                    onB737Approach: () async {
                      await actions.runB737ApproachChecklist();
                    },
                    onB737Landing: () async {
                      await actions.runB737LandingChecklist();
                    },
                    onB737Parking: () async {
                      await actions.runB737ParkingChecklist();
                    },
                  ),
                ),
              ),
            if (FFAppState().EFBpageNumber == 3.0)
              Expanded(
                child: Container(
                  width: double.infinity,
                  height: double.infinity,
                  child: custom_widgets.EfbFlightPlanScreen(
                    width: double.infinity,
                    height: double.infinity,
                    pilotId: FFAppState().SimbreifID.toString(),
                    currentLat: FFAppState().currentLAT,
                    currentLon: FFAppState().currentLON,
                    pdfLink: FFAppState().PDFlinkSimbreif,
                    onDepartureAtisPressed: () async {
                      await actions.professionalAtis(
                        'hiiiii',
                      );
                    },
                    onArrivalAtisPressed: () async {
                      await actions.professionalAtis(
                        'ATIS',
                      );
                    },
                  ),
                ),
              ),
            if (FFAppState().EFBpageNumber == 4.0)
              Expanded(
                child: Container(
                  width: double.infinity,
                  height: double.infinity,
                  child: custom_widgets.ToPerformanceWidget(
                    width: double.infinity,
                    height: double.infinity,
                    pilotId: FFAppState().SimbreifID.toString(),
                    onCalculatePressed: (acType,
                        gw,
                        cg,
                        config,
                        aice,
                        aircond,
                        rwyLen,
                        rwyHdg,
                        slope,
                        rwyCond,
                        aptElev,
                        qnh,
                        temp,
                        windDir,
                        windSpd) async {
                      _model.speedsResult1 =
                          await actions.calculateA320SpeedsFull(
                        gw,
                        config,
                        aptElev,
                        temp,
                        rwyHdg,
                        windDir,
                        windSpd,
                        rwyLen,
                        slope,
                        rwyCond,
                        aircond,
                        aice,
                        cg,
                        qnh,
                      );
                      FFAppState().RWYLENGHTtakeoff = rwyLen;
                      safeSetState(() {});

                      context.pushNamed(
                        TOCalculationWidget.routeName,
                        queryParameters: {
                          'v1Val': serializeParam(
                            getJsonField(
                              _model.speedsResult1,
                              r'''$.v1''',
                            ),
                            ParamType.int,
                          ),
                          'vRVal': serializeParam(
                            getJsonField(
                              _model.speedsResult1,
                              r'''$.vr''',
                            ),
                            ParamType.int,
                          ),
                          'v2Val': serializeParam(
                            getJsonField(
                              _model.speedsResult1,
                              r'''$.v2''',
                            ),
                            ParamType.int,
                          ),
                          'flexVal': serializeParam(
                            getJsonField(
                              _model.speedsResult1,
                              r'''$.flex_temp''',
                            ).toString(),
                            ParamType.String,
                          ),
                          'fSpeed': serializeParam(
                            getJsonField(
                              _model.speedsResult1,
                              r'''$.f_speed''',
                            ),
                            ParamType.int,
                          ),
                          'sSpeed': serializeParam(
                            getJsonField(
                              _model.speedsResult1,
                              r'''$.s_speed''',
                            ),
                            ParamType.int,
                          ),
                          'oSpeed': serializeParam(
                            getJsonField(
                              _model.speedsResult1,
                              r'''$.green_dot_speed''',
                            ),
                            ParamType.int,
                          ),
                          'thsVal': serializeParam(
                            getJsonField(
                              _model.speedsResult1,
                              r'''$.ths''',
                            ).toString(),
                            ParamType.String,
                          ),
                          'eoACC': serializeParam(
                            getJsonField(
                              _model.speedsResult1,
                              r'''$.eo_acc''',
                            ),
                            ParamType.double,
                          ),
                          'isSafe': serializeParam(
                            false,
                            ParamType.bool,
                          ),
                        }.withoutNulls,
                      );

                      safeSetState(() {});
                    },
                  ),
                ),
              ),
            if (FFAppState().EFBpageNumber == 5.0)
              Expanded(
                child: Container(
                  width: double.infinity,
                  height: double.infinity,
                  child: custom_widgets.LdaPerformanceWidget(
                    width: double.infinity,
                    height: double.infinity,
                    pilotId: FFAppState().SimbreifID.toString(),
                    onCalculatePressed: (acType,
                        gw,
                        aptElev,
                        config,
                        aice,
                        revInop,
                        rwyLen,
                        rwyHdg,
                        slope,
                        rwyCond,
                        autobrake,
                        qnh,
                        temp,
                        windDir,
                        windSpd) async {
                      _model.calculateA320LandingNew =
                          await actions.calculateA320Landing(
                        gw,
                        aptElev,
                        temp,
                        qnh,
                        windDir,
                        windSpd,
                        rwyHdg,
                        config,
                        rwyCond,
                        autobrake,
                        revInop,
                        slope,
                        rwyLen,
                        aice,
                      );
                      FFAppState().RWYLENGHTlading = rwyLen;
                      safeSetState(() {});

                      context.pushNamed(
                        LDGCalculationWidget.routeName,
                        queryParameters: {
                          'isSafe': serializeParam(
                            false,
                            ParamType.bool,
                          ),
                          'vapp': serializeParam(
                            getJsonField(
                              _model.calculateA320LandingNew,
                              r'''$.vapp''',
                            ),
                            ParamType.double,
                          ),
                          'vls': serializeParam(
                            getJsonField(
                              _model.calculateA320LandingNew,
                              r'''$.vls''',
                            ),
                            ParamType.double,
                          ),
                          'actualDistance': serializeParam(
                            getJsonField(
                              _model.calculateA320LandingNew,
                              r'''$.actual_distance''',
                            ),
                            ParamType.double,
                          ),
                          'oSpeedL': serializeParam(
                            getJsonField(
                              _model.calculateA320LandingNew,
                              r'''$.o_speed''',
                            ),
                            ParamType.double,
                          ),
                          'sSpeedL': serializeParam(
                            getJsonField(
                              _model.calculateA320LandingNew,
                              r'''$.s_speed''',
                            ),
                            ParamType.double,
                          ),
                          'fSpeedL': serializeParam(
                            getJsonField(
                              _model.calculateA320LandingNew,
                              r'''$.f_speed''',
                            ),
                            ParamType.double,
                          ),
                          'qnhL': serializeParam(
                            getJsonField(
                              _model.calculateA320LandingNew,
                              r'''$.qnh_display''',
                            ),
                            ParamType.double,
                          ),
                          'tempL': serializeParam(
                            getJsonField(
                              _model.calculateA320LandingNew,
                              r'''$.temp_display''',
                            ).toString(),
                            ParamType.String,
                          ),
                          'windL': serializeParam(
                            getJsonField(
                              _model.calculateA320LandingNew,
                              r'''$.wind_display''',
                            ).toString(),
                            ParamType.String,
                          ),
                          'ldgConfigL': serializeParam(
                            getJsonField(
                              _model.calculateA320LandingNew,
                              r'''$.ldg_conf_display''',
                            ).toString(),
                            ParamType.String,
                          ),
                          'safeL': serializeParam(
                            getJsonField(
                              _model.calculateA320LandingNew,
                              r'''$.is_safe''',
                            ),
                            ParamType.bool,
                          ),
                          'runwatStatusL': serializeParam(
                            getJsonField(
                              _model.calculateA320LandingNew,
                              r'''$.runway_status_message''',
                            ).toString(),
                            ParamType.String,
                          ),
                          'runwayRemainingL': serializeParam(
                            getJsonField(
                              _model.calculateA320LandingNew,
                              r'''$.remaining_runway''',
                            ).toString(),
                            ParamType.String,
                          ),
                          'forcedDistanceL': serializeParam(
                            getJsonField(
                              _model.calculateA320LandingNew,
                              r'''$.factored_distance''',
                            ),
                            ParamType.double,
                          ),
                        }.withoutNulls,
                      );

                      safeSetState(() {});
                    },
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
