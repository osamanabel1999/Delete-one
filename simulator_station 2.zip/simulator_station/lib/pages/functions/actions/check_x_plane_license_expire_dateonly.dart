// Automatic FlutterFlow imports
import '/flutter_flow/ff_builtin_enums.dart';
import '/actions/actions.dart' as action_blocks;
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/custom_code/actions/index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart' hide RepeatMode;
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:convert';
import 'package:http/http.dart' as http;

Future<String?> checkXPlaneLicenseExpireDateonly(String? licenseKey) async {
  if (licenseKey == null || licenseKey.trim().isEmpty) {
    return "INVALID_KEY";
  }

  const String token =
      'patZuFHBTfOuzMmP7.b473d75321c56e35e5f7c0d76fcc330098903b08fabc3860400953058a89e39d';
  const String baseId = 'appmz3issohHsNLRM';
  const String tableName = 'Table 1'; // جدول X-Plane الخاص بك

  final String cleanKey = licenseKey.trim();

  // البحث المباشر بـ LicenseKey لسرعة الاستجابة وتوفير الأداء
  final String filterFormula = "{LicenseKey} = '$cleanKey'";
  final Uri url = Uri.parse(
      'https://api.airtable.com/v0/$baseId/${Uri.encodeComponent(tableName)}?filterByFormula=${Uri.encodeComponent(filterFormula)}');

  try {
    final response = await http.get(
      url,
      headers: {
        'Authorization': 'Bearer $token',
      },
    );

    if (response.statusCode >= 200 && response.statusCode < 300) {
      final data = json.decode(response.body);
      final List records = data['records'] ?? [];

      if (records.isEmpty) {
        return "NOT_FOUND";
      }

      final fields = records.first['fields'] ?? {};

      // جلب تاريخ الانتهاء فقط كما هو مسجل في Airtable (تاريخ أو كلمة Lifetime)
      final String expiryDate =
          fields['ExpiryDateOnly']?.toString() ?? 'Lifetime';

      return expiryDate;
    } else {
      return "Error_${response.statusCode}";
    }
  } catch (e) {
    return "Error: $e";
  }
}
