// Automatic FlutterFlow imports
import '/flutter_flow/ff_builtin_enums.dart';
import '/actions/actions.dart' as action_blocks;
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/custom_code/actions/index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart' hide RepeatMode;
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:convert';
import 'package:http/http.dart' as http;

Future<String?> checkMSFSLicensePlan(String? licenseKey) async {
  if (licenseKey == null || licenseKey.trim().isEmpty) {
    return "INVALID_KEY";
  }

  const String token =
      'patZuFHBTfOuzMmP7.b473d75321c56e35e5f7c0d76fcc330098903b08fabc3860400953058a89e39d';
  const String baseId = 'appmz3issohHsNLRM';
  const String tableId = 'tblse0E5FhASxuhmn';

  final String cleanKey = licenseKey.trim();
  final String filterFormula = "NOT({LicenseKey} = '')";
  final Uri url = Uri.parse(
      'https://api.airtable.com/v0/$baseId/$tableId?filterByFormula=${Uri.encodeComponent(filterFormula)}');

  try {
    final response = await http.get(
      url,
      headers: {
        'Authorization': 'Bearer $token',
      },
    );

    if (response.statusCode >= 200 && response.statusCode < 300) {
      final data = json.decode(response.body);
      final List records = data['records'] ?? [];

      for (var record in records) {
        final fields = record['fields'] ?? {};
        if (fields['LicenseKey']?.toString().trim() == cleanKey) {
          // فحص عمود Duration أو PlanType أيهما يحتوي على البيانات
          final String rawDuration =
              fields['Duration']?.toString().trim().toLowerCase() ?? '';
          final String rawPlan =
              fields['PlanType']?.toString().trim().toLowerCase() ?? '';

          final combined = "$rawDuration $rawPlan";

          // لو الكلمة دالة على سنة أو سنوي
          if (combined.contains('1_year') ||
              combined.contains('12_months') ||
              combined.contains('yearly') ||
              combined.contains('سنوي')) {
            return 'Yearly';
          }
          // لو الكلمة دالة على مدى الحياة
          else if (combined.contains('lifetime') ||
              combined.contains('مدى الحياة')) {
            return 'Lifetime';
          }
          // الباقي يعتبر شهري
          else {
            return 'Monthly';
          }
        }
      }
      return "NOT_FOUND";
    } else {
      return "Error_${response.statusCode}";
    }
  } catch (e) {
    return "Error: $e";
  }
}
