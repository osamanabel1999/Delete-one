import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/widgets/index.dart' as custom_widgets;
import 'aircraft_flight_selector_xplane_widget.dart'
    show AircraftFlightSelectorXplaneWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AircraftFlightSelectorXplaneModel
    extends FlutterFlowModel<AircraftFlightSelectorXplaneWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
