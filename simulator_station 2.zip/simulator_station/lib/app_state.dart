import 'package:flutter/material.dart'
    show ChangeNotifier, Color, Colors, VoidCallback;
import '/backend/api_requests/api_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';
import 'dart:convert';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _usernetworkid = prefs.getString('ff_usernetworkid') ?? _usernetworkid;
    });
    _safeInit(() {
      _ipPC = prefs.getString('ff_ipPC') ?? _ipPC;
    });
    _safeInit(() {
      _ivaoVatsimID = prefs.getInt('ff_ivaoVatsimID') ?? _ivaoVatsimID;
    });
    _safeInit(() {
      _SimbreifID = prefs.getInt('ff_SimbreifID') ?? _SimbreifID;
    });
    _safeInit(() {
      _generatedCode = prefs.getString('ff_generatedCode') ?? _generatedCode;
    });
    _safeInit(() {
      _generateCodeMSFS =
          prefs.getString('ff_generateCodeMSFS') ?? _generateCodeMSFS;
    });
    _safeInit(() {
      _savedLicenseKeyMSFS =
          prefs.getString('ff_savedLicenseKeyMSFS') ?? _savedLicenseKeyMSFS;
    });
    _safeInit(() {
      _msfsplan = prefs.getInt('ff_msfsplan') ?? _msfsplan;
    });
    _safeInit(() {
      _xplaneplan = prefs.getInt('ff_xplaneplan') ?? _xplaneplan;
    });
    _safeInit(() {
      _bundleplan = prefs.getInt('ff_bundleplan') ?? _bundleplan;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  int _TabNumber = 1;
  int get TabNumber => _TabNumber;
  set TabNumber(int value) {
    _TabNumber = value;
  }

  String _currentICAO = '';
  String get currentICAO => _currentICAO;
  set currentICAO(String value) {
    _currentICAO = value;
  }

  String _usernetworkid = '';
  String get usernetworkid => _usernetworkid;
  set usernetworkid(String value) {
    _usernetworkid = value;
    prefs.setString('ff_usernetworkid', value);
  }

  int _FailureSubTab = 0;
  int get FailureSubTab => _FailureSubTab;
  set FailureSubTab(int value) {
    _FailureSubTab = value;
  }

  String _PDFlinkSimbreif = '';
  String get PDFlinkSimbreif => _PDFlinkSimbreif;
  set PDFlinkSimbreif(String value) {
    _PDFlinkSimbreif = value;
  }

  double _currentHeading = 0.0;
  double get currentHeading => _currentHeading;
  set currentHeading(double value) {
    _currentHeading = value;
  }

  double _currentX = 0.0;
  double get currentX => _currentX;
  set currentX(double value) {
    _currentX = value;
  }

  double _currentZ = 0.0;
  double get currentZ => _currentZ;
  set currentZ(double value) {
    _currentZ = value;
  }

  String _SIMtime = '';
  String get SIMtime => _SIMtime;
  set SIMtime(String value) {
    _SIMtime = value;
  }

  String _SIMspeed = '';
  String get SIMspeed => _SIMspeed;
  set SIMspeed(String value) {
    _SIMspeed = value;
  }

  List<int> _ActiveFailures = [];
  List<int> get ActiveFailures => _ActiveFailures;
  set ActiveFailures(List<int> value) {
    _ActiveFailures = value;
  }

  void addToActiveFailures(int value) {
    ActiveFailures.add(value);
  }

  void removeFromActiveFailures(int value) {
    ActiveFailures.remove(value);
  }

  void removeAtIndexFromActiveFailures(int index) {
    ActiveFailures.removeAt(index);
  }

  void updateActiveFailuresAtIndex(
    int index,
    int Function(int) updateFn,
  ) {
    ActiveFailures[index] = updateFn(_ActiveFailures[index]);
  }

  void insertAtIndexInActiveFailures(int index, int value) {
    ActiveFailures.insert(index, value);
  }

  double _currentLAT = 0.0;
  double get currentLAT => _currentLAT;
  set currentLAT(double value) {
    _currentLAT = value;
  }

  double _currentLON = 0.0;
  double get currentLON => _currentLON;
  set currentLON(double value) {
    _currentLON = value;
  }

  dynamic _resultXZ;
  dynamic get resultXZ => _resultXZ;
  set resultXZ(dynamic value) {
    _resultXZ = value;
  }

  String _currentALT = '';
  String get currentALT => _currentALT;
  set currentALT(String value) {
    _currentALT = value;
  }

  String _currentSPD = '';
  String get currentSPD => _currentSPD;
  set currentSPD(String value) {
    _currentSPD = value;
  }

  String _ipPC = '';
  String get ipPC => _ipPC;
  set ipPC(String value) {
    _ipPC = value;
    prefs.setString('ff_ipPC', value);
  }

  bool _isIpValid = true;
  bool get isIpValid => _isIpValid;
  set isIpValid(bool value) {
    _isIpValid = value;
  }

  int _ivaoVatsimID = 0;
  int get ivaoVatsimID => _ivaoVatsimID;
  set ivaoVatsimID(int value) {
    _ivaoVatsimID = value;
    prefs.setInt('ff_ivaoVatsimID', value);
  }

  int _SimbreifID = 0;
  int get SimbreifID => _SimbreifID;
  set SimbreifID(int value) {
    _SimbreifID = value;
    prefs.setInt('ff_SimbreifID', value);
  }

  String _web = '';
  String get web => _web;
  set web(String value) {
    _web = value;
  }

  String _generatedCode = '';
  String get generatedCode => _generatedCode;
  set generatedCode(String value) {
    _generatedCode = value;
    prefs.setString('ff_generatedCode', value);
  }

  double _msfsaltitude = 0.0;
  double get msfsaltitude => _msfsaltitude;
  set msfsaltitude(double value) {
    _msfsaltitude = value;
  }

  double _msfsairspeed = 0.0;
  double get msfsairspeed => _msfsairspeed;
  set msfsairspeed(double value) {
    _msfsairspeed = value;
  }

  double _msfsheading = 0.0;
  double get msfsheading => _msfsheading;
  set msfsheading(double value) {
    _msfsheading = value;
  }

  double _msfslatitude = 0.0;
  double get msfslatitude => _msfslatitude;
  set msfslatitude(double value) {
    _msfslatitude = value;
  }

  double _msfslongitude = 0.0;
  double get msfslongitude => _msfslongitude;
  set msfslongitude(double value) {
    _msfslongitude = value;
  }

  double _Checklist = 1.0;
  double get Checklist => _Checklist;
  set Checklist(double value) {
    _Checklist = value;
  }

  double _RWYLENGHTtakeoff = 0.0;
  double get RWYLENGHTtakeoff => _RWYLENGHTtakeoff;
  set RWYLENGHTtakeoff(double value) {
    _RWYLENGHTtakeoff = value;
  }

  double _RWYLENGHTlading = 0.0;
  double get RWYLENGHTlading => _RWYLENGHTlading;
  set RWYLENGHTlading(double value) {
    _RWYLENGHTlading = value;
  }

  String _generateCodeMSFS = '';
  String get generateCodeMSFS => _generateCodeMSFS;
  set generateCodeMSFS(String value) {
    _generateCodeMSFS = value;
    prefs.setString('ff_generateCodeMSFS', value);
  }

  String _licenseExpiryDateMSFS = '';
  String get licenseExpiryDateMSFS => _licenseExpiryDateMSFS;
  set licenseExpiryDateMSFS(String value) {
    _licenseExpiryDateMSFS = value;
  }

  String _licenseExpiryDateXPlane = '';
  String get licenseExpiryDateXPlane => _licenseExpiryDateXPlane;
  set licenseExpiryDateXPlane(String value) {
    _licenseExpiryDateXPlane = value;
  }

  String _savedLicenseKeyMSFS = '';
  String get savedLicenseKeyMSFS => _savedLicenseKeyMSFS;
  set savedLicenseKeyMSFS(String value) {
    _savedLicenseKeyMSFS = value;
    prefs.setString('ff_savedLicenseKeyMSFS', value);
  }

  String _currentPlanTypeMSFS = '';
  String get currentPlanTypeMSFS => _currentPlanTypeMSFS;
  set currentPlanTypeMSFS(String value) {
    _currentPlanTypeMSFS = value;
  }

  int _subscriptionManagepageNumber = 0;
  int get subscriptionManagepageNumber => _subscriptionManagepageNumber;
  set subscriptionManagepageNumber(int value) {
    _subscriptionManagepageNumber = value;
  }

  int _msfsplan = 0;
  int get msfsplan => _msfsplan;
  set msfsplan(int value) {
    _msfsplan = value;
    prefs.setInt('ff_msfsplan', value);
  }

  int _xplaneplan = 0;
  int get xplaneplan => _xplaneplan;
  set xplaneplan(int value) {
    _xplaneplan = value;
    prefs.setInt('ff_xplaneplan', value);
  }

  int _bundleplan = 0;
  int get bundleplan => _bundleplan;
  set bundleplan(int value) {
    _bundleplan = value;
    prefs.setInt('ff_bundleplan', value);
  }

  String _globalExpiryDate = '-';
  String get globalExpiryDate => _globalExpiryDate;
  set globalExpiryDate(String value) {
    _globalExpiryDate = value;
  }

  bool _isProUserMSFS = false;
  bool get isProUserMSFS => _isProUserMSFS;
  set isProUserMSFS(bool value) {
    _isProUserMSFS = value;
  }

  bool _isProUserXplane = false;
  bool get isProUserXplane => _isProUserXplane;
  set isProUserXplane(bool value) {
    _isProUserXplane = value;
  }

  dynamic _usersubscription;
  dynamic get usersubscription => _usersubscription;
  set usersubscription(dynamic value) {
    _usersubscription = value;
  }

  String _radarRwyName = '';
  String get radarRwyName => _radarRwyName;
  set radarRwyName(String value) {
    _radarRwyName = value;
  }

  double _radarLat = 0.0;
  double get radarLat => _radarLat;
  set radarLat(double value) {
    _radarLat = value;
  }

  double _radarLon = 0.0;
  double get radarLon => _radarLon;
  set radarLon(double value) {
    _radarLon = value;
  }

  double _radarHdgRaw = 0.0;
  double get radarHdgRaw => _radarHdgRaw;
  set radarHdgRaw(double value) {
    _radarHdgRaw = value;
  }

  String _gateName = '';
  String get gateName => _gateName;
  set gateName(String value) {
    _gateName = value;
  }

  double _gateLat = 0.0;
  double get gateLat => _gateLat;
  set gateLat(double value) {
    _gateLat = value;
  }

  double _gateLon = 0.0;
  double get gateLon => _gateLon;
  set gateLon(double value) {
    _gateLon = value;
  }

  double _gateHdg = 0.0;
  double get gateHdg => _gateHdg;
  set gateHdg(double value) {
    _gateHdg = value;
  }

  double _PositionSpeedMSFS = 150.0;
  double get PositionSpeedMSFS => _PositionSpeedMSFS;
  set PositionSpeedMSFS(double value) {
    _PositionSpeedMSFS = value;
  }

  String _chartGateName = '';
  String get chartGateName => _chartGateName;
  set chartGateName(String value) {
    _chartGateName = value;
  }

  double _chartGateLat = 0.0;
  double get chartGateLat => _chartGateLat;
  set chartGateLat(double value) {
    _chartGateLat = value;
  }

  double _chartGateLon = 0.0;
  double get chartGateLon => _chartGateLon;
  set chartGateLon(double value) {
    _chartGateLon = value;
  }

  double _chartGateHdg = 0.0;
  double get chartGateHdg => _chartGateHdg;
  set chartGateHdg(double value) {
    _chartGateHdg = value;
  }

  double _efbNavaidTeleportLat = 0.0;
  double get efbNavaidTeleportLat => _efbNavaidTeleportLat;
  set efbNavaidTeleportLat(double value) {
    _efbNavaidTeleportLat = value;
  }

  double _efbNavaidTeleportLon = 0.0;
  double get efbNavaidTeleportLon => _efbNavaidTeleportLon;
  set efbNavaidTeleportLon(double value) {
    _efbNavaidTeleportLon = value;
  }

  double _efbNavaidTeleportHeading = 0.0;
  double get efbNavaidTeleportHeading => _efbNavaidTeleportHeading;
  set efbNavaidTeleportHeading(double value) {
    _efbNavaidTeleportHeading = value;
  }

  double _efbNavaidTeleportAltitude = 0.0;
  double get efbNavaidTeleportAltitude => _efbNavaidTeleportAltitude;
  set efbNavaidTeleportAltitude(double value) {
    _efbNavaidTeleportAltitude = value;
  }

  double _efbNavaidTeleportSpeed = 0.0;
  double get efbNavaidTeleportSpeed => _efbNavaidTeleportSpeed;
  set efbNavaidTeleportSpeed(double value) {
    _efbNavaidTeleportSpeed = value;
  }

  double _msfsTeleportLat = 0.0;
  double get msfsTeleportLat => _msfsTeleportLat;
  set msfsTeleportLat(double value) {
    _msfsTeleportLat = value;
  }

  double _msfsTeleportLng = 0.0;
  double get msfsTeleportLng => _msfsTeleportLng;
  set msfsTeleportLng(double value) {
    _msfsTeleportLng = value;
  }

  double _msfsTeleportAlt = 0.0;
  double get msfsTeleportAlt => _msfsTeleportAlt;
  set msfsTeleportAlt(double value) {
    _msfsTeleportAlt = value;
  }

  double _msfsTeleportHdg = 0.0;
  double get msfsTeleportHdg => _msfsTeleportHdg;
  set msfsTeleportHdg(double value) {
    _msfsTeleportHdg = value;
  }

  double _msfsTeleportSpd = 0.0;
  double get msfsTeleportSpd => _msfsTeleportSpd;
  set msfsTeleportSpd(double value) {
    _msfsTeleportSpd = value;
  }

  double _efbSimulatorTimeSeconds = 0.0;
  double get efbSimulatorTimeSeconds => _efbSimulatorTimeSeconds;
  set efbSimulatorTimeSeconds(double value) {
    _efbSimulatorTimeSeconds = value;
  }

  double _efbGroundSpeed = 0.0;
  double get efbGroundSpeed => _efbGroundSpeed;
  set efbGroundSpeed(double value) {
    _efbGroundSpeed = value;
  }

  double _CurrentY = 0.0;
  double get CurrentY => _CurrentY;
  set CurrentY(double value) {
    _CurrentY = value;
  }

  double _EFBpageNumber = 0.0;
  double get EFBpageNumber => _EFBpageNumber;
  set EFBpageNumber(double value) {
    _EFBpageNumber = value;
  }

  String _receivedCommand = '';
  String get receivedCommand => _receivedCommand;
  set receivedCommand(String value) {
    _receivedCommand = value;
  }

  double _appFuelTotal = 0.0;
  double get appFuelTotal => _appFuelTotal;
  set appFuelTotal(double value) {
    _appFuelTotal = value;
  }

  double _appFuelCenter = 0.0;
  double get appFuelCenter => _appFuelCenter;
  set appFuelCenter(double value) {
    _appFuelCenter = value;
  }

  double _appFuelLInner = 0.0;
  double get appFuelLInner => _appFuelLInner;
  set appFuelLInner(double value) {
    _appFuelLInner = value;
  }

  double _appFuelRInner = 0.0;
  double get appFuelRInner => _appFuelRInner;
  set appFuelRInner(double value) {
    _appFuelRInner = value;
  }

  double _appFuelLOuter = 0.0;
  double get appFuelLOuter => _appFuelLOuter;
  set appFuelLOuter(double value) {
    _appFuelLOuter = value;
  }

  double _appFuelROuter = 0.0;
  double get appFuelROuter => _appFuelROuter;
  set appFuelROuter(double value) {
    _appFuelROuter = value;
  }

  String _syncIcao = '';
  String get syncIcao => _syncIcao;
  set syncIcao(String value) {
    _syncIcao = value;
  }

  String _syncRunway = '';
  String get syncRunway => _syncRunway;
  set syncRunway(String value) {
    _syncRunway = value;
  }

  String _syncGate = '';
  String get syncGate => _syncGate;
  set syncGate(String value) {
    _syncGate = value;
  }

  String _syncChartGate = '';
  String get syncChartGate => _syncChartGate;
  set syncChartGate(String value) {
    _syncChartGate = value;
  }

  double _syncTeleportHdg = 0.0;
  double get syncTeleportHdg => _syncTeleportHdg;
  set syncTeleportHdg(double value) {
    _syncTeleportHdg = value;
  }

  String _syncCommand = '';
  String get syncCommand => _syncCommand;
  set syncCommand(String value) {
    _syncCommand = value;
  }

  double _syncSimTime = 0.0;
  double get syncSimTime => _syncSimTime;
  set syncSimTime(double value) {
    _syncSimTime = value;
  }

  double _syncGroundSpeed = 0.0;
  double get syncGroundSpeed => _syncGroundSpeed;
  set syncGroundSpeed(double value) {
    _syncGroundSpeed = value;
  }

  double _syncSetSpeed = 0.0;
  double get syncSetSpeed => _syncSetSpeed;
  set syncSetSpeed(double value) {
    _syncSetSpeed = value;
  }

  double _syncTeleportRadial = 0.0;
  double get syncTeleportRadial => _syncTeleportRadial;
  set syncTeleportRadial(double value) {
    _syncTeleportRadial = value;
  }

  double _syncTeleportDist = 0.0;
  double get syncTeleportDist => _syncTeleportDist;
  set syncTeleportDist(double value) {
    _syncTeleportDist = value;
  }

  double _syncTeleportAlt = 0.0;
  double get syncTeleportAlt => _syncTeleportAlt;
  set syncTeleportAlt(double value) {
    _syncTeleportAlt = value;
  }

  double _syncTeleportSpd = 0.0;
  double get syncTeleportSpd => _syncTeleportSpd;
  set syncTeleportSpd(double value) {
    _syncTeleportSpd = value;
  }

  int _syncMode = 0;
  int get syncMode => _syncMode;
  set syncMode(int value) {
    _syncMode = value;
  }

  String _syncNavaidSearch = '';
  String get syncNavaidSearch => _syncNavaidSearch;
  set syncNavaidSearch(String value) {
    _syncNavaidSearch = value;
  }

  double _pilotLatXplane = 0.0;
  double get pilotLatXplane => _pilotLatXplane;
  set pilotLatXplane(double value) {
    _pilotLatXplane = value;
  }

  double _pilotLonXplane = 0.0;
  double get pilotLonXplane => _pilotLonXplane;
  set pilotLonXplane(double value) {
    _pilotLonXplane = value;
  }

  double _pilotIasXplane = 0.0;
  double get pilotIasXplane => _pilotIasXplane;
  set pilotIasXplane(double value) {
    _pilotIasXplane = value;
  }

  double _pilotAltXplane = 0.0;
  double get pilotAltXplane => _pilotAltXplane;
  set pilotAltXplane(double value) {
    _pilotAltXplane = value;
  }

  double _pilotHdgXplane = 0.0;
  double get pilotHdgXplane => _pilotHdgXplane;
  set pilotHdgXplane(double value) {
    _pilotHdgXplane = value;
  }

  String _pilotSimbriefXplane = '';
  String get pilotSimbriefXplane => _pilotSimbriefXplane;
  set pilotSimbriefXplane(String value) {
    _pilotSimbriefXplane = value;
  }

  String _SessionID = '';
  String get SessionID => _SessionID;
  set SessionID(String value) {
    _SessionID = value;
  }

  double _pilotWeight = 0.0;
  double get pilotWeight => _pilotWeight;
  set pilotWeight(double value) {
    _pilotWeight = value;
  }

  double _CoPilotWeight = 0.0;
  double get CoPilotWeight => _CoPilotWeight;
  set CoPilotWeight(double value) {
    _CoPilotWeight = value;
  }

  double _RearPAXweight = 0.0;
  double get RearPAXweight => _RearPAXweight;
  set RearPAXweight(double value) {
    _RearPAXweight = value;
  }

  double _BaggageWeight = 0.0;
  double get BaggageWeight => _BaggageWeight;
  set BaggageWeight(double value) {
    _BaggageWeight = value;
  }

  double _ExtraCargoWeight = 0.0;
  double get ExtraCargoWeight => _ExtraCargoWeight;
  set ExtraCargoWeight(double value) {
    _ExtraCargoWeight = value;
  }

  double _pilotLatMsfs = 0.0;
  double get pilotLatMsfs => _pilotLatMsfs;
  set pilotLatMsfs(double value) {
    _pilotLatMsfs = value;
  }

  double _pilotLonMsfs = 0.0;
  double get pilotLonMsfs => _pilotLonMsfs;
  set pilotLonMsfs(double value) {
    _pilotLonMsfs = value;
  }

  double _pilotIasMsfs = 0.0;
  double get pilotIasMsfs => _pilotIasMsfs;
  set pilotIasMsfs(double value) {
    _pilotIasMsfs = value;
  }

  double _pilotAltMsfs = 0.0;
  double get pilotAltMsfs => _pilotAltMsfs;
  set pilotAltMsfs(double value) {
    _pilotAltMsfs = value;
  }

  double _pilotHdgMsfs = 0.0;
  double get pilotHdgMsfs => _pilotHdgMsfs;
  set pilotHdgMsfs(double value) {
    _pilotHdgMsfs = value;
  }

  String _pilotSimbriefMsfs = '';
  String get pilotSimbriefMsfs => _pilotSimbriefMsfs;
  set pilotSimbriefMsfs(String value) {
    _pilotSimbriefMsfs = value;
  }

  double _currentLatMsfs = 0.0;
  double get currentLatMsfs => _currentLatMsfs;
  set currentLatMsfs(double value) {
    _currentLatMsfs = value;
  }

  double _currentLonMsfs = 0.0;
  double get currentLonMsfs => _currentLonMsfs;
  set currentLonMsfs(double value) {
    _currentLonMsfs = value;
  }

  String _currentSpdMsfs = '';
  String get currentSpdMsfs => _currentSpdMsfs;
  set currentSpdMsfs(String value) {
    _currentSpdMsfs = value;
  }

  String _currentAltMsfs = '';
  String get currentAltMsfs => _currentAltMsfs;
  set currentAltMsfs(String value) {
    _currentAltMsfs = value;
  }

  double _currentHeadingMsfs = 0.0;
  double get currentHeadingMsfs => _currentHeadingMsfs;
  set currentHeadingMsfs(double value) {
    _currentHeadingMsfs = value;
  }

  String _simbriefIdMsfs = '';
  String get simbriefIdMsfs => _simbriefIdMsfs;
  set simbriefIdMsfs(String value) {
    _simbriefIdMsfs = value;
  }

  double _TotalFuelMSFS = 0.0;
  double get TotalFuelMSFS => _TotalFuelMSFS;
  set TotalFuelMSFS(double value) {
    _TotalFuelMSFS = value;
  }

  double _CenterTankMSFS = 0.0;
  double get CenterTankMSFS => _CenterTankMSFS;
  set CenterTankMSFS(double value) {
    _CenterTankMSFS = value;
  }

  double _LeftTankMSFS = 0.0;
  double get LeftTankMSFS => _LeftTankMSFS;
  set LeftTankMSFS(double value) {
    _LeftTankMSFS = value;
  }

  double _RightTankMSFS = 0.0;
  double get RightTankMSFS => _RightTankMSFS;
  set RightTankMSFS(double value) {
    _RightTankMSFS = value;
  }

  String _syncIcaoMsfs = '';
  String get syncIcaoMsfs => _syncIcaoMsfs;
  set syncIcaoMsfs(String value) {
    _syncIcaoMsfs = value;
  }

  String _syncRunwayMsfs = '';
  String get syncRunwayMsfs => _syncRunwayMsfs;
  set syncRunwayMsfs(String value) {
    _syncRunwayMsfs = value;
  }

  String _syncGateMsfs = '';
  String get syncGateMsfs => _syncGateMsfs;
  set syncGateMsfs(String value) {
    _syncGateMsfs = value;
  }

  String _syncChartGateMsfs = '';
  String get syncChartGateMsfs => _syncChartGateMsfs;
  set syncChartGateMsfs(String value) {
    _syncChartGateMsfs = value;
  }

  String _syncNavaidSearchMsfs = '';
  String get syncNavaidSearchMsfs => _syncNavaidSearchMsfs;
  set syncNavaidSearchMsfs(String value) {
    _syncNavaidSearchMsfs = value;
  }

  String _syncCommandMsfs = '';
  String get syncCommandMsfs => _syncCommandMsfs;
  set syncCommandMsfs(String value) {
    _syncCommandMsfs = value;
  }

  double _syncSetSpeedMsfs = 0.0;
  double get syncSetSpeedMsfs => _syncSetSpeedMsfs;
  set syncSetSpeedMsfs(double value) {
    _syncSetSpeedMsfs = value;
  }

  double _syncTeleportRadialMsfs = 0.0;
  double get syncTeleportRadialMsfs => _syncTeleportRadialMsfs;
  set syncTeleportRadialMsfs(double value) {
    _syncTeleportRadialMsfs = value;
  }

  double _syncTeleportHdgMsfs = 0.0;
  double get syncTeleportHdgMsfs => _syncTeleportHdgMsfs;
  set syncTeleportHdgMsfs(double value) {
    _syncTeleportHdgMsfs = value;
  }

  double _syncTeleportDistMsfs = 0.0;
  double get syncTeleportDistMsfs => _syncTeleportDistMsfs;
  set syncTeleportDistMsfs(double value) {
    _syncTeleportDistMsfs = value;
  }

  double _syncTeleportAltMsfs = 0.0;
  double get syncTeleportAltMsfs => _syncTeleportAltMsfs;
  set syncTeleportAltMsfs(double value) {
    _syncTeleportAltMsfs = value;
  }

  double _syncTeleportSpdMsfs = 0.0;
  double get syncTeleportSpdMsfs => _syncTeleportSpdMsfs;
  set syncTeleportSpdMsfs(double value) {
    _syncTeleportSpdMsfs = value;
  }

  int _syncModeMsfs = 0;
  int get syncModeMsfs => _syncModeMsfs;
  set syncModeMsfs(int value) {
    _syncModeMsfs = value;
  }

  double _targetSPDworldTourmsfs = 0.0;
  double get targetSPDworldTourmsfs => _targetSPDworldTourmsfs;
  set targetSPDworldTourmsfs(double value) {
    _targetSPDworldTourmsfs = value;
  }

  int _NewPassType = 0;
  int get NewPassType => _NewPassType;
  set NewPassType(int value) {
    _NewPassType = value;
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
