import '/flutter_flow/flutter_flow_ad_banner.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/widgets/index.dart' as custom_widgets;
import '/flutter_flow/revenue_cat_util.dart' as revenue_cat;
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'subscribe_m_s_f_s_model.dart';
export 'subscribe_m_s_f_s_model.dart';

class SubscribeMSFSWidget extends StatefulWidget {
  const SubscribeMSFSWidget({super.key});

  static String routeName = 'SubscribeMSFS';
  static String routePath = '/subscribeMSFS';

  @override
  State<SubscribeMSFSWidget> createState() => _SubscribeMSFSWidgetState();
}

class _SubscribeMSFSWidgetState extends State<SubscribeMSFSWidget> {
  late SubscribeMSFSModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SubscribeMSFSModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: Color(0xFF0B111A),
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Text(
            'MSFS Access Plans',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  font: GoogleFonts.interTight(
                    fontWeight:
                        FlutterFlowTheme.of(context).headlineMedium.fontWeight,
                    fontStyle:
                        FlutterFlowTheme.of(context).headlineMedium.fontStyle,
                  ),
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                  fontWeight:
                      FlutterFlowTheme.of(context).headlineMedium.fontWeight,
                  fontStyle:
                      FlutterFlowTheme.of(context).headlineMedium.fontStyle,
                ),
          ),
          actions: [],
          centerTitle: true,
          elevation: 2.0,
        ),
        body: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            if (FFAppState().NewPassType == 0)
              Expanded(
                child: Container(
                  width: double.infinity,
                  height: double.infinity,
                  child: custom_widgets.Msfscheckout(
                    width: double.infinity,
                    height: double.infinity,
                    monthlyPrice: revenue_cat.offerings!.current!
                        .getPackage('\$rc_monthly')!
                        .storeProduct
                        .priceString,
                    yearlyPrice: revenue_cat.offerings!.current!
                        .getPackage('\$rc_annual')!
                        .storeProduct
                        .priceString,
                    lifetimePrice: revenue_cat.offerings!.current!
                        .getPackage('\$rc_lifetime')!
                        .storeProduct
                        .priceString,
                    onBuyMonthly: () async {
                      _model.mSFSmonthly =
                          await revenue_cat.purchasePackage('\$rc_monthly');
                      if (_model.mSFSmonthly == true) {
                        context.pushNamed(IPpageMSFSWidget.routeName);
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              'Payment failed or was cancelled. Please try again.',
                              style: TextStyle(
                                color: FlutterFlowTheme.of(context).primaryText,
                              ),
                            ),
                            duration: Duration(milliseconds: 4000),
                            backgroundColor:
                                FlutterFlowTheme.of(context).primaryBackground,
                          ),
                        );
                      }

                      safeSetState(() {});
                    },
                    onBuyYearly: () async {
                      _model.mSFSyearly =
                          await revenue_cat.purchasePackage('\$rc_annual');
                      if (_model.mSFSyearly == true) {
                        context.pushNamed(IPpageMSFSWidget.routeName);
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              'Payment failed or was cancelled. Please try again.',
                              style: TextStyle(
                                color: FlutterFlowTheme.of(context).primaryText,
                              ),
                            ),
                            duration: Duration(milliseconds: 4000),
                            backgroundColor:
                                FlutterFlowTheme.of(context).primaryBackground,
                          ),
                        );
                      }

                      safeSetState(() {});
                    },
                    onBuyLifetime: () async {
                      _model.mSFSLifTime =
                          await revenue_cat.purchasePackage('\$rc_lifetime');
                      if (_model.mSFSLifTime == true) {
                        context.pushNamed(IPpageMSFSWidget.routeName);
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              'Payment failed or was cancelled. Please try again.',
                              style: TextStyle(
                                color: FlutterFlowTheme.of(context).primaryText,
                              ),
                            ),
                            duration: Duration(milliseconds: 4000),
                            backgroundColor:
                                FlutterFlowTheme.of(context).primaryBackground,
                          ),
                        );
                      }

                      safeSetState(() {});
                    },
                    onContactUs: () async {
                      await launchURL('https://discord.gg/3jJkuQeKaz');
                    },
                    onBuyBothSims: () async {
                      context.pushNamed(
                          SubscribePackageXplaneMSFSWidget.routeName);
                    },
                    onTermsOfUse: () async {
                      context.pushNamed(TermsOFuseWidget.routeName);
                    },
                    onPrivacyPolicy: () async {
                      context.pushNamed(PrivacyPolicyPageWidget.routeName);
                    },
                  ),
                ),
              ),
            if (responsiveVisibility(
              context: context,
              phone: false,
              tablet: false,
              tabletLandscape: false,
              desktop: false,
            ))
              FlutterFlowAdBanner(
                width: MediaQuery.sizeOf(context).width * 1.0,
                height: 50.0,
                showsTestAd: false,
                iOSAdUnitID: 'ca-app-pub-7880697829268273/6177072322',
                androidAdUnitID: 'ca-app-pub-7880697829268273/5581116466',
              ),
            if (FFAppState().NewPassType == 1)
              Expanded(
                child: Container(
                  width: double.infinity,
                  height: double.infinity,
                  child: custom_widgets.MsfsCheckoutLifetimeOnly(
                    width: double.infinity,
                    height: double.infinity,
                    lifetimePrice: revenue_cat.offerings!.current!
                        .getPackage('\$rc_lifetime')!
                        .storeProduct
                        .priceString,
                    yearlyPrice: revenue_cat.offerings!.current!
                        .getPackage('\$rc_annual')!
                        .storeProduct
                        .priceString,
                    onBuyYearly: () async {
                      _model.mSFSyearly2 =
                          await revenue_cat.purchasePackage('\$rc_annual');
                      if (_model.mSFSyearly2 == true) {
                        context.pushNamed(IPpageMSFSWidget.routeName);
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              'Payment failed or was cancelled. Please try again.',
                              style: TextStyle(
                                color: FlutterFlowTheme.of(context).primaryText,
                              ),
                            ),
                            duration: Duration(milliseconds: 4000),
                            backgroundColor:
                                FlutterFlowTheme.of(context).primaryBackground,
                          ),
                        );
                      }

                      safeSetState(() {});
                    },
                    onBuyLifetime: () async {
                      _model.mSFSLifTime2 =
                          await revenue_cat.purchasePackage('\$rc_lifetime');
                      if (_model.mSFSLifTime2 == true) {
                        context.pushNamed(IPpageMSFSWidget.routeName);
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              'Payment failed or was cancelled. Please try again.',
                              style: TextStyle(
                                color: FlutterFlowTheme.of(context).primaryText,
                              ),
                            ),
                            duration: Duration(milliseconds: 4000),
                            backgroundColor:
                                FlutterFlowTheme.of(context).primaryBackground,
                          ),
                        );
                      }

                      safeSetState(() {});
                    },
                    onContactUs: () async {
                      await launchURL('https://discord.gg/3jJkuQeKaz');
                    },
                    onBuyBothSims: () async {
                      context.pushNamed(
                        SubscribePackageXplaneMSFSWidget.routeName,
                        extra: <String, dynamic>{
                          '__transition_info__': TransitionInfo(
                            hasTransition: true,
                            transitionType: PageTransitionType.fade,
                          ),
                        },
                      );
                    },
                    onTermsOfUse: () async {
                      context.pushNamed(TermsOFuseWidget.routeName);
                    },
                    onPrivacyPolicy: () async {
                      context.pushNamed(PrivacyPolicyPageWidget.routeName);
                    },
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
